"""Basic training routines and loss functions."""

from .training_routine import train

__all__ = ['train']
